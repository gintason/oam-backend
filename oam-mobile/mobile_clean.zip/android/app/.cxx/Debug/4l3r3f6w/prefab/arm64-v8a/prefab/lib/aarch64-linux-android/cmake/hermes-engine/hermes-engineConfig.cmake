if(NOT TARGET hermes-engine::hermesvm)
add_library(hermes-engine::hermesvm SHARED IMPORTED)
set_target_properties(hermes-engine::hermesvm PROPERTIES
    IMPORTED_LOCATION "/Users/computer/.gradle/caches/9.3.1/transforms/c449d585a0b9f9506f41d7e3e6ebdaa0/transformed/hermes-android-250829098.0.16-debug/prefab/modules/hermesvm/libs/android.arm64-v8a/libhermesvm.so"
    INTERFACE_INCLUDE_DIRECTORIES "/Users/computer/.gradle/caches/9.3.1/transforms/c449d585a0b9f9506f41d7e3e6ebdaa0/transformed/hermes-android-250829098.0.16-debug/prefab/modules/hermesvm/include"
    INTERFACE_LINK_LIBRARIES ""
)
endif()

