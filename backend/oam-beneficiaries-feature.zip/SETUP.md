# Saved Beneficiaries / Recent Numbers & Meters

Auto-saves the phone number, meter, or smartcard from every successful Airtime /
Data / Electricity / Cable purchase, and shows them back on the purchase screens
for one-tap re-use. Tapping a saved item fills the form (and, for meters and
smartcards, re-triggers your existing account-name lookup).

This ships as **new drop-in files only** — nothing existing is overwritten. The
four purchase screens each need a few lines added; those are given verbatim
below (your live screens are already translated, so applying small snippets is
safer than swapping whole files).

---

## 1. Backend (Django / DRF) — separate repo

### Install
1. Copy the `backend/beneficiaries/` folder into your Django project root.
2. Add it to settings:
   ```python
   INSTALLED_APPS = [
       # ...
       "beneficiaries",
   ]
   ```
3. Include the URLs under your existing `/api/v1/` prefix (same place `billing`
   is included):
   ```python
   # config/urls.py (or wherever /api/v1/ is assembled)
   urlpatterns = [
       # ...
       path("api/v1/", include("beneficiaries.urls")),
   ]
   ```
4. Migrate:
   ```bash
   python manage.py makemigrations beneficiaries
   python manage.py migrate
   ```
   On Render, add `makemigrations beneficiaries` is **not** needed if you commit
   the migration — generate it locally and commit `beneficiaries/migrations/`.
   The pre-deploy chain stays as-is; `migrate` picks it up.

### Endpoints
| Method | Path | Purpose |
|---|---|---|
| GET | `/api/v1/beneficiaries/?type=airtime` | list (most-recent first, capped at 12) |
| POST | `/api/v1/beneficiaries/` | create-or-refresh (idempotent) |
| PATCH | `/api/v1/beneficiaries/{id}/` | set `label` (nickname) |
| DELETE | `/api/v1/beneficiaries/{id}/` | remove |

`type` is one of `airtime`, `data`, `electricity`, `cable`.

### Server-side auto-save (recommended)
Call the helper from wherever a purchase is confirmed successful — your billing
purchase view, or the card-payment webhook. It's idempotent and never raises, so
it's safe to call unconditionally on success:

```python
from beneficiaries.services import upsert_beneficiary

# ... after the order is created and status == "success":
upsert_beneficiary(
    user=request.user,
    service_type=order.category,          # "airtime" | "data" | "electricity" | "cable"
    account_identifier=order.recipient,   # phone / meter / smartcard
    biller_code=serializer.validated_data["code"],   # the provider code used
    biller_name=order.biller_name,
    customer_name=getattr(order, "customer_name", "") or "",
)
```

> `biller_code` is what the frontend `<select>` binds to, so storing it is what
> lets a tapped meter/smartcard re-select the right disco/provider. If `order`
> doesn't carry the code, read it from the request/serializer as shown.

**You don't strictly have to touch the purchase view** — the frontend also saves
on success (below), and because the endpoint is idempotent the two never
conflict. Server-side saving is just the more robust of the two; do both if you
like, do either if you prefer.

---

## 2. Frontend — this repo

### New files (copy in as-is)
- `src/services/beneficiaries.ts` — API client.
- `src/hooks/useSaveBeneficiary.ts` — fire-and-forget save for purchase success.
- `src/components/RecentBeneficiaries.tsx` — the tap-to-fill row/chips.
- `src/i18n/locales/*.json` — adds the `beneficiaries` namespace in all 20
  languages (only new keys added; nothing else changed).

### Screen wiring
Each screen needs: two imports, one hook call, the `<RecentBeneficiaries>`
element above its identifier input, and a save call inside the wallet-purchase
`onSuccess`. The state variable names below already exist in your screens.

Add these imports to all four screens:
```tsx
import RecentBeneficiaries from "../../components/RecentBeneficiaries";
import { useSaveBeneficiary } from "../../hooks/useSaveBeneficiary";
```
and near the top of each component body:
```tsx
const saveBeneficiary = useSaveBeneficiary();
```

#### BuyAirtime.tsx
Above the phone `<input>`:
```tsx
<RecentBeneficiaries
  type="airtime"
  enabled={isVerified}
  onPick={(b) => {
    setPhone(b.account_identifier);
    if (b.biller_code) { setNetwork(b.biller_code); setTouchedNetwork(true); }
  }}
/>
```
In `purchase.onSuccess`, replace `setOrder(data)` with:
```tsx
onSuccess: (data) => {
  setOrder(data);
  if (data.status === "success")
    saveBeneficiary({
      service_type: "airtime",
      account_identifier: data.recipient,
      biller_code: network,
      biller_name: data.biller_name,
    });
},
```

#### BuyData.tsx
Above the phone `<input>`:
```tsx
<RecentBeneficiaries
  type="data"
  enabled={isVerified}
  onPick={(b) => {
    setPhone(b.account_identifier);
    if (b.biller_code) setNetwork(b.biller_code);
  }}
/>
```
In `purchase.onSuccess`:
```tsx
onSuccess: (data) => {
  setOrder(data);
  if (data.status === "success")
    saveBeneficiary({
      service_type: "data",
      account_identifier: data.recipient,
      biller_code: network,
      biller_name: data.biller_name,
    });
},
```

#### BuyElectricity.tsx
Above the meter `<input>`:
```tsx
<RecentBeneficiaries
  type="electricity"
  enabled={isVerified}
  onPick={(b) => {
    setDisco(b.biller_code);
    setMeter(b.account_identifier);
    setCustomerName(undefined);   // clear so the auto-verify effect re-runs
    setVerificationId("");
  }}
/>
```
Your existing auto-verify `useEffect` (fires once `disco` is set and the meter
is ≥ 11 digits) does the account-name lookup automatically after the pick.
In `purchase.onSuccess`:
```tsx
onSuccess: (data) => {
  setOrder(data);
  if (data.status === "success")
    saveBeneficiary({
      service_type: "electricity",
      account_identifier: data.recipient,
      biller_code: disco,
      biller_name: data.biller_name,
      customer_name: data.customer_name,
    });
},
```

#### BuyCable.tsx
Above the smartcard `<input>`:
```tsx
<RecentBeneficiaries
  type="cable"
  enabled={isVerified}
  onPick={(b) => {
    setProvider(b.biller_code);
    setSmartcard(b.account_identifier);
    setCustomerName(undefined);   // clear so the auto-verify effect re-runs
    setVerificationId("");
  }}
/>
```
In `purchase.onSuccess`:
```tsx
onSuccess: (data) => {
  setOrder(data);
  if (data.status === "success")
    saveBeneficiary({
      service_type: "cable",
      account_identifier: data.recipient,
      biller_code: provider,
      biller_name: data.biller_name,
      customer_name: data.customer_name,
    });
},
```

> If a screen also delivers via the **card** flow (not just wallet), add the same
> `saveBeneficiary({...})` call inside that mutation's success handler too —
> wherever the delivered order object is available. For card flows that redirect
> to Paystack and finish server-side, prefer the backend `upsert_beneficiary`
> call instead, since the frontend never sees the final success.

---

## How it behaves
- **Auto-save**: every successful purchase records the identifier. Re-paying the
  same number/meter just floats it back to the top (timestamp bump) — no
  duplicates, because the row is unique per `(user, service, identifier)`.
- **Auto-fill**: tapping a chip fills the number; tapping a saved meter/smartcard
  fills it *and* re-selects the provider *and* re-runs your verify lookup.
- **Empty state**: the component renders nothing until the user has beneficiaries,
  so first-time screens look exactly as they do now.
- **Safety**: saving is fire-and-forget on the client and never-raises on the
  server — a beneficiary write can never turn a good purchase into a visible
  error.
- **i18n**: labels ("Recent numbers" / "Saved meters" / "Saved smartcards" /
  "Remove") are translated across all 20 languages. Hausa / Igbo / Yoruba, as
  ever, are worth a native-speaker pass.
