import { ArrowRight } from "lucide-react";
import { ECOMMERCE_PARTNERS, partnerMonogram } from "../services/ecommerce";
import { Link, useNavigate } from "react-router-dom";
import type { ReactElement } from "react";

/** Closing call-to-action, then the footer. */

export function CTA() {
  const navigate = useNavigate();

  return (
    <section className="mx-auto max-w-6xl px-5 py-14 sm:px-6 sm:py-24">
      <div className="relative overflow-hidden rounded-3xl bg-[#0B3D22] px-8 py-14 sm:px-14 sm:py-20 text-center">
        <div
          className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full bg-brand-red/20 blur-3xl"
          aria-hidden="true"
        />
        <h2 className="relative font-display text-3xl font-medium text-white sm:text-4xl lg:text-5xl">
          One app. Endless possibilities.
        </h2>
        <p className="relative mx-auto mt-4 max-w-md text-[15px] leading-relaxed text-white/70 sm:text-base">
          Join thousands paying bills, shopping, and moving money the easy way.
          It's free to start.
        </p>
        <div className="relative mt-8 flex flex-wrap justify-center gap-3">
          <button
            onClick={() => navigate("/sign-up")}
            className="inline-flex h-12 items-center gap-2 rounded-lg bg-brand-red px-6 text-[15px] font-medium text-white transition hover:brightness-95 active:scale-[0.98]"
          >
            Create your account
            <ArrowRight size={18} strokeWidth={1.75} />
          </button>
          <button
            onClick={() => navigate("/sign-in")}
            className="h-12 rounded-lg border border-white/35 bg-transparent px-6 text-[15px] font-medium text-white transition hover:bg-white/5 active:scale-[0.98]"
          >
            Sign in
          </button>
        </div>
      </div>
    </section>
  );
}

/**
 * Footer links.
 *
 * Services and Explore point at the real in-app routes — those sit behind
 * RequireAuth, so a signed-out visitor is sent to sign-in and lands where they
 * meant to go afterwards. Company pages are public: someone deciding whether to
 * trust you with their money shouldn't have to register first to read your
 * terms.
 */
const FOOTER_COLS: { heading: string; links: { label: string; to: string }[] }[] = [
  {
    heading: "Services",
    links: [
      { label: "Airtime & Data", to: "/services/airtime" },
      { label: "Cable TV", to: "/services/cable" },
      { label: "Electricity", to: "/services/electricity" },
      { label: "Gift Cards", to: "/services/giftcards" },
      { label: "Money Transfer", to: "/wallet/send" },
    ],
  },
  {
    heading: "Explore",
    links: [
      { label: "Marketplace", to: "/marketplace" },
      { label: "Artisans", to: "/artisans" },
      { label: "Flights", to: "/travel/flights" },
      { label: "Hotels", to: "/travel/hotels" },
      { label: "Car Hire", to: "/travel/carhire" },
    ],
  },
  {
    heading: "Company",
    links: [
      { label: "About", to: "/about" },
      { label: "Contact", to: "/contact" },
      { label: "Help Center", to: "/help" },
      { label: "Terms", to: "/terms" },
      { label: "Privacy", to: "/privacy" },
    ],
  },
];

/* Brand logos as inline SVG (lucide removed brand icons). Each takes the
   current text colour via fill="currentColor" so hover states just work. */
type IconProps = { className?: string };

const XLogo = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" className={className} aria-hidden="true">
    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
  </svg>
);

const FacebookLogo = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" className={className} aria-hidden="true">
    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
  </svg>
);

const InstagramLogo = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" className={className} aria-hidden="true">
    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
  </svg>
);

const TikTokLogo = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" className={className} aria-hidden="true">
    <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
  </svg>
);

const WhatsAppLogo = ({ className }: IconProps) => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" className={className} aria-hidden="true">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);

type Social = { label: string; href: string; Logo: (p: IconProps) => ReactElement };
/**
 * Social links. Same handle everywhere: @oamplatform.
 *
 * WhatsApp is the odd one out — it has no @handle. wa.me needs a PHONE NUMBER
 * in full international format, so the placeholder below must be replaced with
 * the real business line before launch, or the icon leads nowhere. If you'd
 * rather use a WhatsApp Channel, send me its invite link instead.
 */
const WHATSAPP_NUMBER = "2340000000000"; // TODO: real business number

const SOCIALS: Social[] = [
  { label: "X (Twitter)", href: "https://x.com/oamplatform", Logo: XLogo },
  { label: "Facebook",    href: "https://facebook.com/oamplatform", Logo: FacebookLogo },
  { label: "Instagram",   href: "https://instagram.com/oamplatform", Logo: InstagramLogo },
  { label: "TikTok",      href: "https://tiktok.com/@oamplatform", Logo: TikTokLogo },
  { label: "WhatsApp",    href: `https://wa.me/${WHATSAPP_NUMBER}`, Logo: WhatsAppLogo },
];

export function Footer() {
  return (
    <footer className="border-t border-hairline bg-paper">
      <div className="mx-auto max-w-6xl px-5 py-12 sm:px-6 sm:py-14">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-5">
          {/* brand + follow us */}
          <div className="lg:col-span-2">
            <div className="font-display text-xl font-semibold text-ink">
              O<span className="text-brand-red">.</span>A
              <span className="text-brand-green">.</span>M
              <span className="text-brand-red">.</span>
            </div>
            <p className="mt-3 max-w-[240px] text-[13px] leading-relaxed text-muted">
              All services. One app. Endless possibilities.
            </p>

            <h4 className="mb-3 mt-7 text-[13px] font-medium uppercase tracking-wider text-ink">
              Follow us
            </h4>
            <div className="flex items-center gap-2.5">
              {SOCIALS.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  aria-label={s.label}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-hairline bg-paper text-muted transition hover:border-brand-green/40 hover:bg-brand-green/5 hover:text-brand-green"
                >
                  <s.Logo />
                </a>
              ))}
            </div>
          </div>

          {FOOTER_COLS.map((col) => (
            <div key={col.heading}>
              <h4 className="mb-3 text-[13px] font-medium uppercase tracking-wider text-ink">
                {col.heading}
              </h4>
              <ul className="space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.to}>
                    <Link to={l.to} className="text-[14px] text-muted transition hover:text-ink">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-start justify-between gap-4 border-t border-hairline pt-6 sm:flex-row sm:items-center">
          <p className="text-[13px] text-muted">
            © {new Date().getFullYear()} OAM. All rights reserved.
          </p>
          <div className="flex flex-wrap items-center gap-x-5 gap-y-3">
            {ECOMMERCE_PARTNERS.map((pt) =>
              pt.logo ? (
                <img key={pt.slug} src={pt.logo} alt={pt.name} title={pt.name} className="h-6 w-auto max-w-[84px] object-contain opacity-70 grayscale transition hover:opacity-100 hover:grayscale-0" loading="lazy" />
              ) : (
                <span key={pt.slug} title={pt.name} className="flex h-6 min-w-[24px] items-center justify-center rounded px-1 text-[11px] font-bold text-white" style={{ backgroundColor: pt.accent }}>
                  {partnerMonogram(pt.name)}
                </span>
              )
            )}
          </div>
        </div>
      </div>
    </footer>
  );
}
