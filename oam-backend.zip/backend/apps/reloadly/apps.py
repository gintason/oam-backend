from django.apps import AppConfig


class ReloadlyConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.reloadly"
